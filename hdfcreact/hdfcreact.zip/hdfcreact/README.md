This project was bootstrapped with [Create React App](https://github.com/facebook/create-react-app).
\$ npm run build

> hdfckickstarter@0.1.0 build C:\Users\sriva\Desktop\testgit\hdfckickstarter
> react-scripts build

Creating an optimized production build...
Compiled successfully.

File sizes after gzip:

39.25 KB build\static\js\1.89f8accc.chunk.js
12.85 KB build\static\css\1.2a3f5d8a.chunk.css
2.05 KB build\static\js\main.188e6afa.chunk.js
763 B build\static\js\runtime~main.229c360f.js
200 B build\static\css\main.80178358.chunk.css

The project was built assuming it is hosted at the server root.
You can control this with the homepage field in your package.json.
For example, add this to build it for GitHub Pages:

"homepage" : "http://myname.github.io/myapp",

The build folder is ready to be deployed.
You may serve it with a static server:

serve -s build

Find out more about deployment here:

http://bit.ly/CRA-deploy
